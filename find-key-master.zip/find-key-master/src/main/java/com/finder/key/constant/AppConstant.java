package com.finder.key.constant;

public class AppConstant {
    private AppConstant() {}

    public static final String SPACE = " ";
    public static final String REMOVE_PROP_TEMP = "Loại {0} do (K - {1} = Q+ nên K= {2})";
    public static final String NOT_REMOVE_PROP_TEMP = "Không thể loại {0} do (K - {1} != Q+ nên K = {2})";
}
