package com.finder.key.service;

import com.finder.key.model.AllKey;
import com.finder.key.model.AllKeyFinder;
import com.finder.key.model.Key;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AllKeyFinderService {

    public List<AllKey> find(Key key) {
        AllKeyFinder allKeys = new AllKeyFinder(key.getProps(), key.getListF());
        List<AllKey> allKeyList = new ArrayList<>();
        for (int i = 0; i < allKeys.getXi().size() - 1; i++) {
            AllKey build = AllKey.builder()
                    .xi(allKeys.getXi().get(i))
                    .xiUSrc(allKeys.getXiUSrc().get(i))
                    .xiUSrcPlus(allKeys.getXiUSrcPlus().get(i))
                    .superKey(allKeys.getSuperKeys().get(i))
                    .key(allKeys.getKeys().get(i))
                    .build();
            allKeyList.add(build);
        }
        return allKeyList;
    }
}
