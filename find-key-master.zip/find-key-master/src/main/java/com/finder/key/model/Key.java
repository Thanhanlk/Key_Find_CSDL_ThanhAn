
package com.finder.key.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Key {
    private Set<String> props = new TreeSet<>();
    private Map<String, String> listF = new HashMap<>();

    public void clear() {
        props.clear();
        listF.clear();
    }
}
