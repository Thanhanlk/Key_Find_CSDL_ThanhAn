package com.finder.key.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AllKey {
    private String xi;
    private String xiUSrc;
    private String xiUSrcPlus;
    private String superKey;
    private String key;
}
