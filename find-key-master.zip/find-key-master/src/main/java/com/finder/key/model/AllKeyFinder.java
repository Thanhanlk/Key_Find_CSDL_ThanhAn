
package com.finder.key.model;

import lombok.Getter;

import java.util.*;

import static com.finder.key.constant.AppConstant.SPACE;

@Getter
public class AllKeyFinder {

    private String tn = "";
    private List<String> tg = new LinkedList<>();
    private List<String> xi = new LinkedList<>();
    private List<String> xiUSrc = new LinkedList<>();
    private List<String> xiUSrcPlus = new LinkedList<>();
    private List<String> superKeys = new LinkedList<>();
    private List<String> keys = new LinkedList<>();
    private int minOfSPK;
    private List<String> list = new LinkedList<>();


    public AllKeyFinder(Set<String> props, Map<String, String> listF) {
        minOfSPK = props.size();
        handleTNAndTG(props, listF);
        handleXI();
        handleXiUTN();
        handleXiUTNPlus(listF);
        findSuperKeys();
        findKeys();
    }

    private void handleTNAndTG(Set<String> props, Map<String, String> listF) {
        StringBuilder stringBuilder = new StringBuilder();
        for (var prop : props) {
            if (containKey(prop, listF)) {
                if (!containValue(prop, listF)) {
                    stringBuilder.append(prop);
                } else {
                    tg.add(prop);
                }

            }
        }
        if (stringBuilder.isEmpty()) {
            tn = SPACE;
        } else {
            tn = stringBuilder.toString();
        }
    }

    private boolean containKey(String prop, Map<String, String> listF) {
        return this.checkContain(prop, listF.keySet());
    }

    private boolean containValue(String prop, Map<String, String> listF) {
        return this.checkContain(prop, listF.values());
    }

    private boolean checkContain(String target, Collection<String> source) {
        return source.stream()
                .anyMatch(x -> x.contains(target));
    }

    private void handleXI() {
        int n = tg.size();
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < (1 << n); i++) {
            for (int j = 0; j < n; j++) {
                if ((i & (1 << j)) > 0) {
                    stringBuilder.append(tg.get(j));
                }
            }
            xi.add(stringBuilder.isEmpty() ? SPACE : stringBuilder.toString());
            stringBuilder.setLength(0);
        }
        xi.add(String.join("", tg));
    }

    private void handleXiUTN() {
        List<String> strings = xi.stream()
                .map(x -> {
                    if (SPACE.equals(x) && SPACE.equals(tn)) return SPACE;
                    if (SPACE.equals(x)) return tn;
                    if (SPACE.equals(tn)) return x;
                    return x + tn;
                })
                .toList();
        xiUSrc.addAll(strings);
    }

    private void handleXiUTNPlus(Map<String, String> listF) {
        String QPlus = "";
        int count = listF.size();
        for (var item : xiUSrc) {
            int i = 0;
            String tempK = item;
            if (SPACE.equals(item)) {
                xiUSrcPlus.add(SPACE);
            } else {
                while (i <= count) {
                    String key = findKey(listF.keySet(), tempK);
                    if ("".equals(key)) {
                        if ("".equals(QPlus)) {
                            xiUSrcPlus.add(item);
                        } else {
                            if (QPlus.length() == minOfSPK) {
                                xiUSrcPlus.add("Q+");
                            } else {
                                xiUSrcPlus.add(QPlus);
                            }
                            QPlus = "";
                        }
                        break;
                    } else {
                        QPlus = findKPlus(listF.get(key), item, QPlus);
                        tempK = QPlus;
                    }
                    i++;
                }
            }
            list.clear();
        }
    }

    private String findKPlus(String value, String tempK, String QPlus) {
        char[] charArray = value.toCharArray();
        for (char c : charArray) {
            String s = Character.toString(c);
            if (!QPlus.contains(s)) {
                QPlus += s;
            }
        }
        charArray = tempK.toCharArray();
        for (char c : charArray) {
            String s = Character.toString(c);
            if (!QPlus.contains(s)) {
                QPlus += s;
            }
        }
        return QPlus;
    }

    private String findKey(Set<String> keySet, String tempK) {
        for (var i : keySet) {
            if (list.contains(i)) {
                continue;
            }
            if (checkContains(i, tempK)) {
                list.add(i);
                return i;
            }
        }
        return "";
    }

    private boolean checkContains(String keyModel, String k) {
        int length = keyModel.length();
        char[] charArray = keyModel.toCharArray();
        for (int i = 0; i < length; i++) {
            if (!k.contains(Character.toString(charArray[i]))) {
                return false;
            }
        }
        return true;
    }

    private void findSuperKeys() {
        int n = xiUSrcPlus.size();
        for (int i = 0; i < n; i++) {

            if (xiUSrcPlus.get(i).equals("Q+")) {
                if (xiUSrc.get(i).length() < minOfSPK) {
                    minOfSPK = xiUSrc.get(i).length();
                }
                superKeys.add(xiUSrc.get(i));
            } else {
                superKeys.add(SPACE);
            }
        }
    }

    private void findKeys() {
        for (var item : superKeys) {
            if (item.length() == minOfSPK) {
                keys.add(item);
            } else {
                keys.add(SPACE);
            }
        }
    }
}
