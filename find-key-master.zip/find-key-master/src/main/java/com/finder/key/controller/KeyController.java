package com.finder.key.controller;

import com.finder.key.model.AllKey;
import com.finder.key.model.Key;
import com.finder.key.service.AllKeyFinderService;
import com.finder.key.service.KeyFinderService;
import io.micrometer.common.util.StringUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Controller
@RequiredArgsConstructor
public class KeyController {

    private final KeyFinderService keyFinderService;
    private final AllKeyFinderService allKeyFinderService;


    @GetMapping("/index")
    public String index() {
        return "index";
    }

    @PostMapping(value = "/index", params = {"tn", "tg"})
    public String index(
            @RequestParam String tn,
            @RequestParam String tg,
            Model model
    ) {
        Map<String, String> f = this.getF(tg);
        Set<String> listProps = this.getListProps(tn);
        Key key = new Key(listProps, f);
        List<String> keys = this.keyFinderService.find(key);
        List<AllKey> allKeyList = this.allKeyFinderService.find(key);

//        List<String> con = allKeyList.stream()
//                .map(AllKey::getKey)
//                .filter(StringUtils::isNotBlank)
//                .toList();
//        keys.add("Vậy khoá của Q là: " + con);

        model.addAttribute("allKey", allKeyList);
        model.addAttribute("findKey", keys);
        model.addAttribute("f", f);
        model.addAttribute("tn", tn);
        model.addAttribute("tg", tg);
        return "index";
    }

    private Map<String, String> getF(String tg) {
        String PTHStr = tg.replaceAll("\\s+", "");
        String[] arrPTH = PTHStr.split(",");
        return Stream.of(arrPTH)
                .map(pth -> pth.split("-"))
                .collect(Collectors.toMap(lr -> lr[0], lr -> lr[1], (k1, k2) -> k1, LinkedHashMap::new));
    }

    private Set<String> getListProps(String tn) {
        tn = tn.replaceAll("\\s+", "");
        return new TreeSet<>(List.of(tn.split(",")));
    }
}
