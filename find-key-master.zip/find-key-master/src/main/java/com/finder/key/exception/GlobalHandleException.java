package com.finder.key.exception;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
@Slf4j
public class GlobalHandleException {

    @ExceptionHandler({Exception.class})
    public String error(Exception ex) {
        log.error(ex.getMessage(), ex);
        return "error";
    }
}
