
package com.finder.key.service;

import com.finder.key.model.Key;
import org.springframework.stereotype.Service;
import org.springframework.web.context.annotation.RequestScope;

import java.text.MessageFormat;
import java.util.*;

import static com.finder.key.constant.AppConstant.NOT_REMOVE_PROP_TEMP;
import static com.finder.key.constant.AppConstant.REMOVE_PROP_TEMP;

@Service
@RequestScope
public class KeyFinderService {

    private final Set<String> k = new TreeSet<>();
    private final LinkedList<String> list = new LinkedList<>();
    private String prop;

    public List<String> find(Key model) {
        List<String> finalResult = new ArrayList<>();
        k.addAll(model.getProps());
        int count = 0;
        int index = 0;
        int n = model.getProps().size();
        boolean check = true;
        while (count < n) {

            Set<String> lastTemp = new TreeSet<>(k);
            Set<String> tempK = new TreeSet<>(createSubK(k, index));
            Set<String> result = new TreeSet<>(tempK);

            while (true) {
                String key = getKey(model.getListF().keySet(), tempK);
                // tìm tập bao đóng
                Set<String> qPlus;
                if ("".equals(key)) {
                    qPlus = new TreeSet<>(tempK);
                } else {
                    qPlus = getQPlus(model.getListF().get(key), tempK);
                }
                if (qPlus.equals(model.getProps())) {
                    k.clear();
                    k.addAll(result);
                    check = true;
                    key = "";
                    list.clear();
                    count++;
                    String format = MessageFormat.format(REMOVE_PROP_TEMP, prop, prop, k);
                    finalResult.add(format);
                    break;
                } else {
                    tempK.clear();
                    tempK.addAll(qPlus);
                    check = false;
                }
                if ("".equals(key)) {
                    list.clear();
                    count++;
                    finalResult.add(MessageFormat.format(NOT_REMOVE_PROP_TEMP, prop, prop, k));
                    break;
                }
            }
            if (!check) {
                k.clear();
                k.addAll(lastTemp);
                index++;
            }
        }
        finalResult.add("Vậy khoá của Q là: " + k);
        return finalResult;
    }

    private String getKey(Set<String> keySet, Set<String> tempK) {
        for (var i : keySet) {
            if (list.contains(i)) {
                continue;
            }
            if (checkContains(i, tempK)) {
                list.add(i);
                return i;
            }
        }
        return "";
    }

    private boolean checkContains(String keyModel, Set<String> k) {
        char[] charArray = keyModel.toCharArray();
        for (char c : charArray) {
            if (!k.contains(Character.toString(c))) {
                return false;
            }
        }
        return true;
    }

    private Set<String> getQPlus(String value, Set<String> tempK) {
        char[] charArray = value.toCharArray();
        Set<String> result = new TreeSet<>(tempK);
        for (char c : charArray) {
            result.add(Character.toString(c));
        }
        return result;
    }

    private Set<String> createSubK(Set<String> k, int index) {
        Set<String> temp = new TreeSet<>();
        int count = 0;
        for (var i : k) {
            if (count == index) {
                prop = i;
                count++;
                continue;
            }
            temp.add(i);
            count++;
        }
        return temp;
    }
}
