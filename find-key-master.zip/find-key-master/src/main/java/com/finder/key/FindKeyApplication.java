package com.finder.key;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FindKeyApplication {

    public static void main(String[] args) {
        SpringApplication.run(FindKeyApplication.class, args);
    }

}
