package com.finder.key;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KeyFinderServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
